import { A, e } from "./mermaid-parser.core.DhoQDADk.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
