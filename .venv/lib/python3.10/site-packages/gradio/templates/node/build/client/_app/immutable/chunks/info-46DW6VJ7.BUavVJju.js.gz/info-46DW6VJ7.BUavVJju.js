import { I, c } from "./mermaid-parser.core.DhoQDADk.js";
export {
  I as InfoModule,
  c as createInfoServices
};
