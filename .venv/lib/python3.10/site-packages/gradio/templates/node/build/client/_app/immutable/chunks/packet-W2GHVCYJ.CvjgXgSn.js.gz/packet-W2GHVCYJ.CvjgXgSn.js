import { P, a } from "./mermaid-parser.core.DhoQDADk.js";
export {
  P as PacketModule,
  a as createPacketServices
};
